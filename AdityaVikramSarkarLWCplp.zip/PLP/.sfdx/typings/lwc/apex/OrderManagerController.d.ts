declare module "@salesforce/apex/OrderManagerController.getRecordId" {
  export default function getRecordId(): Promise<any>;
}
declare module "@salesforce/apex/OrderManagerController.getProducts" {
  export default function getProducts(param: {rbVal: any, searchText: any, pbId: any}): Promise<any>;
}
declare module "@salesforce/apex/OrderManagerController.createOrderProducts" {
  export default function createOrderProducts(param: {selectedProducts: any, priceBookId: any, orderId: any}): Promise<any>;
}
