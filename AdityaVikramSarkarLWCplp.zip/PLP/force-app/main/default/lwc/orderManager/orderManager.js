import { LightningElement, track } from 'lwc';
import createOrderProducts from '@salesforce/apex/OrderManagerController.createOrderProducts';
import getProducts from '@salesforce/apex/OrderManagerController.getProducts';
import getRecordId from '@salesforce/apex/OrderManagerController.getRecordId';


export default class OrderManager extends LightningElement {

    listOfProduct;
    requiredQuantity = 0;
    error;
    recordId = '';
    orderCreated = false;
    displayList = false;
    selectedItems = true;
    showFinalTable = false;
    @track value = '';
    selectedProductsList = [];

    get options() {
        return [
            { label: 'Product Brand', value: 'Brand__c' },
            { label: 'Product Name', value: 'Name' },
            { label: 'MRP', value: 'UnitPrice' }
        ];
    }


    handleSuccess(event) {
        alert('Order Created');
        this.orderCreated = true;
        if (this.orderCreated) {
            getRecordId()
                .then(result => {
                    this.recordId = result;
                    console.log(this.recordId);
                })
        }
    }


    addItem(event) {
        if (this.recordId == null || this.recordId == '') {
            alert('Please create a record first');
        } else if (this.requiredQuantity < 0) {
            alert('Please enter a valid value');
        } else {
            this.selectedItems = false;
            var prodId = event.target.value;
            var i = -1;
            var selectedProduct = new Object();
            for (var product of this.listOfProduct) {
                i++;
                if (prodId == product.Id) {
                    selectedProduct.Id = product.Id;
                    selectedProduct.Name = product.Name;
                    selectedProduct.ProductCode = product.ProductCode;
                    selectedProduct.Brand__c = product.Brand__c;
                    selectedProduct.StockQuantity__c = product.StockQuantity__c;
                    selectedProduct.Quantity = 0;
                    selectedProduct.UnitPrice = 0;
                    selectedProduct.ListPrice = product.ListPrice;
                    selectedProduct.Discount = 0;
                    selectedProduct.PriceBookEntryId = product.PriceBookEntryId;
                    break;
                }
            }
            if (!this.selectedProductsList.some(prod => prod.Id === selectedProduct.Id)) {
                this.selectedProductsList.push(selectedProduct);
            }
            this.selectedItems = true;
        }
    }


    deleteProduct(event) {
        var id = event.target.value;
        for (var product of this.selectedProductsList) {
            if (id == product.Id) {
                const index = this.selectedProductsList.indexOf(product);
                this.selectedProductsList.splice(index, 1)
            }
        }
        this.selectedItems = false;
        this.selectedItems = true;
    }


    findProducts(event) {
        var searchValue = event.target.value;
        console.log('inside getProducts list');
        if (searchValue.length > 0) {
            getProducts({ rbVal: this.value, searchText: searchValue, pbId: '01s2x000001NenWAAS' })
                .then(result => {
                    console.log(result);
                    console.log('inside get products success 1');
                    this.listOfProduct = JSON.parse(result);
                    console.log('inside get products success 2');
                    this.displayList = true;
                    console.log(this.listOfProduct);
                })
                .catch(error => {
                    console.log('inside get products error');
                    this.error = error;
                });

        } else {
            this.displayList = false;
        }
    }


    updateQty(event) {
        var index = -1;
        for (var product of this.selectedProductsList) {
            index++;
            if (event.target.name == product.Id) {
                break;
            }
        }
        this.selectedProductsList[index].Quantity = event.target.value;
    }


    updatingDiscount(event) {
        var idx = -1;
        for (var product of this.selectedProductsList) {
            idx++;
            if (event.target.name == product.Id) {
                break;
            }
        }
        this.selectedProductsList[idx].Discount = event.target.value;
    }


    saveOrderProducts(event) {
        this.selectedItems = false;
        for (var product of this.selectedProductsList) {
            var selectedProduct = new Object();
            if (product.Quantity > 10) {
                selectedProduct.Quantity = '1';
                selectedProduct.ListPrice = 0;
                selectedProduct.UnitPrice = 0;
                selectedProduct.Discount = 100;
                selectedProduct.Id = product.Id;
                selectedProduct.Name = product.Name;
                selectedProduct.ProductCode = product.ProductCode;
                selectedProduct.Brand = product.Brand__c;
                selectedProduct.Stock_Quantity = product.StockQuantity__c;
                selectedProduct.PriceBookEntryId = product.PriceBookEntryId;
                this.selectedProductsList.push(selectedProduct);
            }
            product.UnitPrice = product.ListPrice - (product.ListPrice * product.Discount / 100);
        }


        createOrderProducts({ selectedProducts: JSON.stringify(this.selectedProductsList), priceBookId: '01s2x000001NenWAAS', orderId: this.recordId })
            .then(result => {
                console.log('OrderID : ' + result);
            })
            .catch(error => {
                console.log(error);
            });
        this.showFinalTable = true;
    }

}